=======
Credits
=======

Development Lead
----------------

* Mishbah Razzaque <mishbahx@gmail.com>

Contributors
------------

* Dries Desmet <dries@urga.be>
* Sasha Matijasic <sasha@logit.hr>
