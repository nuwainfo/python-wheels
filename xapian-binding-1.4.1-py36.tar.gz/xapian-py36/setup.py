#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: setup.py 10019 2017-06-03 14:49:17Z Lavender $
#
# Copyright (c) 2017 Lavender, Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: Lavender $ (last)
# $Date: 2017-06-03 22:49:17 +0800 (�g��, 03 ���� 2017) $
# $Revision: 10019 $

from setuptools import setup

setup(
    name='xapian',
    version='1.0.0',
    description='Pre-built xapian for centos7.',
    license='Proprietary License',
    author='Lavendar',
    author_email='lavendar.chan@nuwainfo.com',
    url='http://www.nuwainfo.com/',
    packages=[
        'xapian',
    ],
    package_data={'xapian': ['*']},
)