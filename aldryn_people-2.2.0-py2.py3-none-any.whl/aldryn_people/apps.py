# -*- coding: utf-8 -*-
from django.apps import AppConfig


class AldrynPeople(AppConfig):
    name = 'aldryn_people'
    verbose_name = 'Aldryn People'
