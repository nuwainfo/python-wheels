# -*- coding: utf-8 -*-
__version__ = '2.2.0'

DEFAULT_APP_NAMESPACE = 'aldryn_people'
