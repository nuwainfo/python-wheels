#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id$
#
# Copyright (c) 2019 Lavender, Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author$
# $Date$
# $Revision$

from setuptools import setup

setup(
    name='xapian',
    version='1.4.29',
    description='Pre-built xapian for rockylinux9.',
    license='Proprietary License',
    author='Leon',
    author_email='Leon.Liu@nuwainfo.com',
    url='http://www.nuwainfo.com/',
    packages=[
        'xapian',
    ],
    package_data={'xapian': ['*']},
)