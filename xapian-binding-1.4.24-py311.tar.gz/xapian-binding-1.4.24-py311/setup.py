#!/usr/bin/env python
# -*- coding: utf-8 -*-
# $Id: setup.py 10019 2017-06-03 14:49:17Z Lavender $
#
# Copyright (c) 2019 Lavender, Ltd, All Rights Reserved.
#
# Licensed under the Proprietary License,
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at our web site.
#
# See the License for the specific language governing permissions and
# limitations under the License.
#
# $Author: How $ (last)
# $Date: 2024-02-24 13:4936:17 +0800 (�g��, 03 ���� 2017) $
# $Revision: 10019 $

from setuptools import setup

setup(
    name='xapian',
    version='1.4.24',
    description='Pre-built xapian for rockylinux9.',
    license='Proprietary License',
    author='How',
    author_email='how.kao@nuwainfo.com',
    url='http://www.nuwainfo.com/',
    packages=[
        'xapian',
    ],
    package_data={'xapian': ['*']},
)